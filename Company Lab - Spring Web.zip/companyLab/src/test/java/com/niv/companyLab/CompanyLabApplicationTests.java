package com.niv.companyLab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
